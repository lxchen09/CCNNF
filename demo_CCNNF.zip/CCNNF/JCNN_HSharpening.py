import time

import torch
from torch import nn
from torchkeras import summary
import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat
from sklearn.decomposition import PCA
import cv2 as cv
from torch.utils.data import DataLoader, Dataset
import datetime
from MyLib import Train_DS, MyModel, MyTest
from cnn_functions import ProposedHPNN_train


class Param:
    def __init__(self):
        super(Param, self).__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.D = 60
        self.Psize = 7
        self.iPad = int(np.floor(self.Psize / 2))
        self.SimuBand = {0: np.arange(0, 43), 1: np.arange(43, 74), 2: np.arange(74, 103)}
        self.lr = 1.0000e-04
        self.mom = 0.9000
        self.batchsize = 64
        self.epochs = 200
        self.mode = 2
        self.log_step_freq = 100
        self.Hbands = None
        self.Mbands = len(self.SimuBand.keys())
        self.Hsize = None
        self.Msize = None
        self.Hsize_channel_last = None
        self.Msize_channel_no = None

        self.eta = 0.4000
        self.em = loadmat('opts.mat')['opts']['em'][0, 0]
        self.em_t = None
        self.em_msi = None
        self.em_msi_t = None
        self.srf = None
        self.S_t = None

    def set_param_to_tensor(self):
        if (self.em is not None) & (self.em_msi is not None) & (self.srf is not None):
            self.em_t = torch.tensor(data=self.em, dtype=torch.float32, device=self.device)
            self.em_msi_t = torch.tensor(data=self.em_msi, dtype=torch.float32, device=self.device)
            self.S_t = torch.tensor(data=self.srf, dtype=torch.float32, device=self.device)
            Param.print_info_tensor(em_t=self.em_t, em_msi_t=self.em_msi_t, S_t=self.S_t)
        else:
            print("the parameter is None!")

    def get_data(self, *args):
        name = str(args[0])
        MAX = np.max(loadmat('UOP_resrat4.mat')['HHSI'].astype(np.float32))
 
        if name == 'LHSI' or name == 'HPAN' or name == 'HHSI':
            data = loadmat('UOP_resrat4.mat')[name].astype(np.float32) / MAX
            if name == 'LHSI':
                self.Hsize_channel_last = data.shape
                Param.print_info(LHSI=data)
            elif name == 'HPAN':
                self.Msize_channel_no = data.shape
                Param.print_info(HPAN=data)
            else:
                Param.print_info(HHSI=data)
            return data
        else:
            print("wrong name!")
            return None

    @staticmethod
    def print_info(**kwargs):
        for key in kwargs.keys():
            value = kwargs[key]
            print("{} --> shape: {}, dtype: {}".format(key, value.shape, value.dtype))
        Param.print_bar()

    @staticmethod
    def print_info_tensor(**kwargs):
        for key in kwargs.keys():
            value = kwargs[key]
            print("{} --> shape: {}, dtype: {}, device: {}".format(key, value.shape, value.dtype, value.device))
        Param.print_bar()

    @staticmethod
    def print_bar():
        now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print("\n" + "==========" * 3 + " %s " % now_time + "==========" * 3 + "\n")

    @staticmethod
    def PatchGene(Img, Psize, Stride=1):  # divide the image into patches N*C*H*W
        print("Patch Generating......")

        iPad = int(np.floor(Psize / 2))
        sz = Img.shape

        Img = cv.copyMakeBorder(Img, iPad, iPad, iPad, iPad, cv.BORDER_REFLECT)
        blks = np.ceil(np.divide(sz[0:2], Stride)).astype(np.int)

        Samples = np.zeros((Psize, Psize, Img.shape[2], np.prod(blks)), dtype=np.float32)

        for j in range(blks[1]):
            for i in range(blks[0]):
                Samples[:, :, :, i+j*blks[1]] = Img[i*Stride : i*Stride+Psize, j*Stride : j*Stride+Psize, :]

        Samples = np.transpose(Samples, (3, 2, 0, 1))
        Param.print_info(dataset=Samples)
        return Samples

    @staticmethod
    def get_Model(in_ch1, out_ch1, in_ch2, out_ch2, param):

        print("Setting the model...")
        cnn = {0: MyModel(in_channel=in_ch1, out_channel=out_ch1, stage=1, mode=param.mode),
               1: MyModel(in_channel=in_ch2, out_channel=out_ch2, stage=2, mode=param.mode)}
        print("Summarizing the model 1...")
        summary(model=cnn[0], input_shape=(in_ch1, 7, 7))
        print("Summarizing the model 2...")
        summary(model=cnn[1], input_shape=(in_ch2, 7, 7))
        print("Transferring the model to device...")
        if param.device == 'gpu':
            cnn[0], cnn[1] = cnn.get(0).cuda(), cnn.get(1).cuda()
        print("model1 --> device: {}, model2 --> device: {}".format(next(cnn[0].parameters()).device, next(cnn[1].parameters()).device))

        print("Finishing...")
        return cnn


def pca_transform(LHSI, LMSI, param): # do PCA transform, simulate MS image
    T_pca = {}
    for j in range(param.Mbands):
        pca = PCA(n_components=param.Hbands)
        pca.fit(LHSI[:,param.SimuBand[j]])
        T_pca[j] = np.transpose(pca.components_)
        T_pca[j][:,0] = T_pca[j][:,0]  / np.sum(T_pca[j][:,0] )
        
        LMSI[:, j] = LHSI[:, param.SimuBand[j]] @ T_pca[j][:, 0]
    LHSI = np.reshape(LHSI, param.Hsize)
    LMSI = np.reshape(LMSI, (param.Hsize[0], param.Hsize[1], param.Mbands))
    param.print_info(LHSI=LHSI, LMSI=LMSI)
    return LHSI, LMSI, T_pca


def get_srf(T_pca, param):      # compute SRF between HS and synthesized MS images
    param.srf = np.zeros((param.Mbands, param.Hsize[2]), dtype=np.float32) 
    for j in range(param.Mbands):
        param.srf[j, param.SimuBand[j]] = T_pca[j][:, 0].T  # initial SRTM 
    param.em_msi = param.srf @ param.em  # initial end-member matrix of MS image
    param.print_info(em=param.em, em_msi=param.em_msi, srf=param.srf)

def img_blur_and_resize(LHSI, LMSI, HPAN, param, sigma=1):  # down-sample images to construct training set
    s = round(param.Msize[0] / param.Hsize[0])
 
    LLHSI = cv.GaussianBlur(LHSI, (2*s-1, 2*s-1), sigma)   
    LLHSI = cv.resize(LLHSI, (0, 0), None, 1/s, 1/s, cv.INTER_LINEAR)
    LLHSI = cv.resize(LLHSI, (0, 0), None, s, s, cv.INTER_LINEAR)

    LLMSI = cv.GaussianBlur(LMSI, (2*s-1, 2*s-1), sigma)  
    LLMSI = cv.resize(LLMSI, (0, 0), None, 1/s, 1/s, cv.INTER_LINEAR) 
    LLMSI = cv.resize(LLMSI, (0, 0), None, s, s, cv.INTER_LINEAR)

    LHPAN = cv.GaussianBlur(HPAN, (2*s-1, 2*s-1), sigma)  
    LHPAN = cv.resize(LHPAN, (0, 0), None, 1/s, 1/s, cv.INTER_LINEAR)

    param.print_info(LLHSI=LLHSI, LLMSI=LLMSI, LHPAN=LHPAN)
    return LLHSI, LLMSI, LHPAN

def get_train_set(LLHSI, LLMSI, LHPAN, LHSI, LMSI, param):  # construct training set
    if param.mode == 1: # training fashon 1
        train_x = {0: param.PatchGene(np.concatenate((LLMSI, np.expand_dims(LHPAN, axis=2)), axis=2), param.Psize),
                   1: param.PatchGene(LLHSI, param.Psize)}
        train_y = {0: param.PatchGene(LHSI, param.Psize),
                   1: param.PatchGene(LMSI, param.Psize)}
        train = DataLoader(dataset=Train_DS(x0=train_x[0], x1=train_x[1], y0=train_y[0], y1=train_y[1], param=param),
                           batch_size=param.batchsize, shuffle=True)
    else:   # training fashon 2
        train_x = {0: param.PatchGene(np.concatenate((LLMSI, np.expand_dims(LHPAN, axis=2)), axis=2), param.Psize),
                   1: param.PatchGene(np.concatenate((LLHSI, LMSI), axis=2), param.Psize)}
        train_y = {0: param.PatchGene(LMSI - LLMSI, param.Psize),
                   11: param.PatchGene(LHSI, param.Psize),
                   12: param.PatchGene(LMSI, param.Psize)}
        train = DataLoader(dataset=Train_DS(x0=train_x[0], x1=train_x[1], y0=train_y[0], y1=train_y[11], y12=train_y[12],param=param), 
                           batch_size=param.batchsize, shuffle=True)
    return train, train_x[0].shape[1], train_x[1].shape[1]


def get_test_set(LHSI, LMSI, HPAN, param):  # process data under original resolution to construct testing set
    iPad = param.iPad
    HHSI = cv.resize(LHSI, (HPAN.shape[0], HPAN.shape[1]), interpolation=cv.INTER_LINEAR)  # imreisze
    HHSI = np.pad(HHSI, ((iPad, iPad), (iPad, iPad), (0, 0)), 'symmetric')
    HHSI = torch.tensor(data=HHSI.transpose((2, 0, 1)), dtype=torch.float32, device=param.device)

    HMSI = cv.resize(LMSI, (HPAN.shape[0], HPAN.shape[1]), interpolation=cv.INTER_LINEAR)  # imreisze
    HMSI = np.pad(HMSI, ((iPad, iPad), (iPad, iPad), (0, 0)), 'symmetric')
    HMSI = torch.tensor(data=HMSI.transpose((2, 0, 1)), dtype=torch.float32, device=param.device)

    HPAN = np.pad(HPAN, ((iPad, iPad), (iPad, iPad)), 'symmetric')
    HPAN = torch.tensor(data=np.expand_dims(HPAN, axis=0), dtype=torch.float32, device=param.device)

    # network training and testing
    test_y = np.zeros((param.Msize[0], param.Msize[1], param.em.shape[1]), dtype=np.float32)  
    test_y = np.pad(test_y, ((iPad, iPad), (iPad, iPad), (0, 0)), 'symmetric')
    test_y = torch.tensor(data=test_y.transpose((2, 0, 1)), dtype=torch.float32, device=param.device)

    test_num = np.zeros((test_y.shape[1], test_y.shape[2]), dtype=np.float32)
    test_num = torch.tensor(data=test_num, dtype=torch.float32, device=param.device)

    param.print_info_tensor(HHSI=HHSI, HMSI=HMSI, HPAN=HPAN, test_y=test_y, test_num=test_num)

    return HHSI, HMSI, HPAN, test_y, test_num


if __name__ == '__main__':
    opts = Param()
    opts.mode = 1
    Psize = opts.Psize

    LHSI, HPAN = opts.get_data('LHSI'), opts.get_data("HPAN")   # get image data
    opts.Hsize, opts.Msize = opts.Hsize_channel_last, opts.Msize_channel_no
    LHSI, LMSI, T_pca = pca_transform(LHSI=np.reshape(LHSI, (-1, opts.Hsize[2])),
                                      LMSI=np.zeros((np.prod(opts.Hsize[0:2]), opts.Mbands), dtype=np.float32), param=opts)
    get_srf(T_pca=T_pca, param=opts)

    # downsample the images to generate training samples
    LLHSI, LLMSI, LHPAN = img_blur_and_resize(LHSI=LHSI, LMSI=LMSI, HPAN=HPAN, param=opts) 
    train_loader, x1_ch, x2_ch = get_train_set(LLHSI=LLHSI, LLMSI=LLMSI, LHPAN=LHPAN, LHSI=LHSI, LMSI=LMSI, param=opts)

    HHSI, HMSI, HPAN, test_y, test_num = get_test_set(LHSI=LHSI, LMSI=LMSI, HPAN=HPAN, param=opts) # upsample HS data to prepare testing set

    Tr = {}
    test_x = {}
    opts.set_param_to_tensor()
    if opts.mode == 1:          # CCNNF-1 
        model = opts.get_Model(in_ch1=x1_ch, out_ch1=opts.Mbands, in_ch2=x2_ch + opts.Mbands, out_ch2=opts.D, param=opts) # prepare model parameters

        Start_1 = time.time()
        Train_Loss = ProposedHPNN_train(model=model, train_loader=train_loader, param=opts)  #  network training
        Tr[1] = time.time() - Start_1
        print('ProposedCNN_training Time: {}'.format(Tr[1]))
        
        Start_2 = time.time()
        for j in range(opts.Msize[1]):      # predict each pixel under original resolution by row-by-row fashion
            test_x[0] = torch.zeros(size=(opts.Msize[0], opts.Mbands+1, Psize, Psize), dtype=torch.float32, device=opts.device)
            test_x[1] = torch.zeros(size=(opts.Msize[0], opts.Hsize[2], Psize, Psize), dtype=torch.float32, device=opts.device)
            for i in range(opts.Msize[0]):
                test_x[0][i, :, :, :] = torch.cat((HMSI[:, i:i+Psize, j:j+Psize], HPAN[:, i:i+Psize, j:j+Psize]), dim=0) # concatenate patches
                test_x[1][i, :, :, :] = HHSI[:, i:i+Psize, j:j+Psize]
            
            model[0].eval(), model[1].eval()           
            with torch.no_grad():
                results_0 = model[0](test_x[0])     # detail injection sub-network forward propagation
                results_1 = model[1](torch.cat((test_x[1], results_0 + test_x[0][:, 0:opts.Mbands, :, :]), dim=1)) # unmixing sub-network forward propagation
                
            for i in range(opts.Msize[0]):
                test_y[:, i: i+Psize, j:j+Psize] += results_1[i, :, :, :]  # return each patch to the location of pixels in HR HS image
                test_num[i: i+Psize, j:j+Psize] += 1
        Tr[2] = time.time() - Start_2
        print('ProposedCNN_testing Time: {}'.format(Tr[2]))

    else: # CCNNF-2 
        model = opts.get_Model(in_ch1=x1_ch, out_ch1=opts.Mbands, in_ch2=x2_ch, out_ch2=opts.D, param=opts)  # prepare model parameters

        Start_1 = time.time()
        Train_Loss = ProposedHPNN_train(model=model, train_loader=train_loader, param=opts)  #  network training
        Tr[1] = time.time() - Start_1
        print('ProposedCNN_training time: {}'.format(Tr[1]))

        test_x = {}
        Start_2 = time.time()
        for j in range(opts.Msize[1]):      # predict each pixel under original resolution by row-by-row fashion
            test_x[0] = torch.zeros(size=(opts.Msize[0], opts.Mbands+1, Psize, Psize), dtype=torch.float32, device=opts.device)
            test_x[1] = torch.zeros(size=(opts.Msize[0], opts.Hsize[2]+opts.Mbands, Psize, Psize), dtype=torch.float32, device=opts.device)
            for i in range(opts.Msize[0]):
                test_x[0][i, :, :, :] = torch.cat((HMSI[:, i:i+Psize, j:j+Psize], HPAN[:, i:i+Psize, j:j+Psize]), dim=0) # concatenate patches
                
            model[0].eval()
            with torch.no_grad():
                results_0 = model[0](test_x[0]) # detail injection sub-network forward propagation
            for i in range(opts.Msize[0]):
                test_x[1][i, :, :, :] = torch.cat((HHSI[:, i:i+Psize, j:j+Psize], results_0[i, :, :, :] + HMSI[:, i:i+Psize, j:j+Psize]), dim=0)
           
            model[1].eval()
            with torch.no_grad():
                results_1 = model[1](test_x[1]) # unmixing sub-network forward propagation

            for i in range(opts.Msize[0]):
                test_y[:, i:i+Psize, j:j+Psize] += results_1[i, :, :, :]  # return each patch to the location of pixels in HR HS image
                test_num[i:i+Psize, j:j+Psize] += 1
        Tr[2] = time.time() - Start_2
        print('ProposedCNN_testing stage time: {}'.format(Tr[2]))

    test_y1 = (test_y / test_num)  # average of overlapped areas
    test_y1 = test_y1[:, opts.iPad: opts.iPad + opts.Msize[0], opts.iPad: opts.iPad + opts.Msize[1]].permute((1, 2, 0))
    test_y1 = (torch.reshape(test_y1, (-1, test_y1.shape[2]))).T
    ZHPNN = torch.reshape((opts.em_t @ test_y1).T, (opts.Msize[0], opts.Msize[1], opts.Hsize[2])) # reconstruct HR HS image
    ZHPNN = ZHPNN.cpu().numpy()


    # UIQI
    hhsi = opts.get_data('HHSI') # reference HS image
    UIQI = np.zeros([1, opts.Hsize[2]], dtype=np.float32)
    for bb in range(opts.Hsize[2]):
        tempA, tempB = ZHPNN[:, :, bb].reshape(1, -1), hhsi[:, :, bb].reshape(1, -1)
        temp = np.cov(tempA, tempB)
        sigmaAB, sigmaA, sigmaB = temp[0, 1], temp[0, 0], temp[1, 1]
        miuA, miuB = np.mean(tempA), np.mean(tempB)
        RMSE = np.mean((tempA - tempB) ** 2)
        UIQI[0, bb] = 4 * sigmaAB * miuA * miuB / ((sigmaA + sigmaB) * (miuA ** 2 + miuB ** 2))

    print('UIQI:{}'.format(np.mean(UIQI[0:opts.Hsize[2]])))
    plt.imshow(ZHPNN[:, :, 60])
    plt.show()
