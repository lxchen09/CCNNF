from torchkeras import summary
from torch import nn
import torch
import datetime
from torch.utils.data import Dataset


class MyModel(nn.Module):

    def __init__(self, in_channel, out_channel, stage=1, mode=1):
        super(MyModel, self).__init__()

        self.stage = stage if (stage == 1 or stage == 2) else print("wrong stage")

        self.conv1 = nn.Conv2d(in_channels=in_channel, out_channels=32, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(num_features=32)
        self.relu1 = nn.ReLU()

        self.conv2 = nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(num_features=32)
        self.relu2 = nn.ReLU()

        self.conv3 = nn.Conv2d(in_channels=32, out_channels=32, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(num_features=32)
        self.relu3 = nn.ReLU()

        self.conv4 = nn.Conv2d(in_channels=32, out_channels=out_channel, kernel_size=3, padding=1)
        self.bn4 = nn.BatchNorm2d(num_features=out_channel)
        self.activation = nn.ReLU() if stage == 1 else nn.Softmax2d()
        if mode == 2 and stage == 1:
            self.activation = nn.LeakyReLU(negative_slope=1)

    def forward(self, x):
        x = self.relu1(self.bn1(self.conv1(x)))
        x = self.relu2(self.bn2(self.conv2(x)))
        x = self.relu3(self.bn3(self.conv3(x)))
        x = self.activation(self.bn4(self.conv4(x)))
        return x


class Train_DS(Dataset):
    """
    # statement:
    1. Transferring the datasets to tensor within device that default value is 'cpu'
    """

    def __init__(self, x0, x1, y0, y1, param, y12=None):
        super(Train_DS, self).__init__()
        self.len = x0.shape[0]
        self.y12 = y12

        self.x0_tensor = torch.tensor(data=x0, dtype=torch.float32, device=param.device)
        self.x1_tensor = torch.tensor(data=x1, dtype=torch.float32, device=param.device)
        self.y0_tensor = torch.tensor(data=y0, dtype=torch.float32, device=param.device)
        self.y1_tensor = torch.tensor(data=y1, dtype=torch.float32, device=param.device)
        param.print_info_tensor(train_x0=self.x0_tensor,
                                train_x1=self.x1_tensor,
                                train_y0=self.y0_tensor,
                                train_y1=self.y1_tensor)
        if y12 is not None:
            self.y12_tensor = torch.tensor(data=self.y12, dtype=torch.float32, device=param.device)
            param.print_info_tensor(train_y12=self.y12_tensor)

        param.print_bar()

    def __getitem__(self, item):
        if self.y12 is None:
            return self.x0_tensor[item], self.x1_tensor[item], self.y0_tensor[item], self.y1_tensor[item]
        else:
            return self.x0_tensor[item], self.x1_tensor[item], self.y0_tensor[item], self.y1_tensor[item], \
                   self.y12_tensor[item]

    def __len__(self):
        return self.len


class MyTest(Dataset):
    def __init__(self, x1, x2):
        super(MyTest, self).__init__()
        self.x1 = x1
        self.x2 = x2
        self.len = x1.shape[0]

    def __getitem__(self, item):
        return self.x1[item], self.x2[item]

    def __len__(self):
        return self.len


class LLoss:

    @staticmethod
    def rmse_or_mse(y, o):
        y = torch.reshape(y, (y.shape[0], -1))
        o = torch.reshape(o, (y.shape[0], -1))
        loss = torch.mean(torch.sum((y - o) ** 2, dim=0))
        # loss = torch.sqrt(loss)
        # error = o - y
        return loss  # , error

    @staticmethod
    def rmse4d(y, o):
        loss = torch.mean(torch.sum(torch.sum(torch.sum((y - o) ** 2, dim=0), dim=0), dim=0))
        # error = o - y
        return loss  # , error

    @staticmethod
    def cross_entropy(y, o):
        y = torch.reshape(y, (y.shape[0], -1))
        o = torch.reshape(o, (y.shape[0], -1))
        loss = -1 * torch.mean(torch.sum(y * torch.log(o), dim=0))
        # error = -1 * y / o
        return loss  # , error
