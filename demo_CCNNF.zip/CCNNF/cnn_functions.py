# -*- coding: utf-8 -*-
"""
Created on Tue Apr 13 16:38:33 2021

@author: lxchen09
"""
import numpy as np
import torch
from torch import nn
from itertools import chain
from MyLib import LLoss


def loss_func(result, y0, y1, param):
    AH = torch.reshape(input=result.permute((1, 2, 3, 0)), shape=(result.shape[1], -1)) # predicted abundance matrix
    Y0 = torch.reshape(input=y0.permute((1, 2, 3, 0)), shape=(y0.shape[1], -1))  # Target HS image
    Y1 = torch.reshape(input=y1.permute((1, 2, 3, 0)), shape=(y1.shape[1], -1))  # Target MS image
    O0 = param.em_t @ AH        # Predicted HS image
    O1 = param.em_msi_t @ AH    # Predicted MS image

    loss = 0.5 * LLoss.rmse_or_mse(Y0, O0) + 0.5 * LLoss.rmse_or_mse(Y1, O1) + \
            0.5 * torch.mean(torch.sum(param.eta*AH**2, dim=0)) + \
                0.5 * torch.sum(torch.sum((param.em_msi_t - param.S_t @ param.em_t)**2))
    return loss, AH.data, Y0.data, Y1.data


def param_update(AH, Y0, Y1, param):  # update of Eh, Em, SRF
    em = param.em_t.data
    em_msi = param.em_msi_t.data
    S = param.S_t.data

    param.em_t.data = em * (Y0 @ AH.T + S.T @ em_msi) / (em @ (AH @ AH.T) + S.T @ S @ em)
    param.em_msi_t.data = em_msi * (Y1 @ AH.T + S @ param.em_t.data) / (em_msi @ (AH @ AH.T) + em_msi)
    param.S_t.data = S * (param.em_msi_t.data @ param.em_t.data.T) / (S @ (param.em_t.data @ param.em_t.data.T))


def ProposedHPNN_train(model, train_loader, param):
    train_loss = torch.zeros((len(train_loader), param.epochs))
    param.Hbands = param.em_t.shape[0]
    param.Mbands = param.em_msi_t.shape[0]

    if param.mode == 1:  # CCNNF-1
        optimizer = torch.optim.SGD(params=chain(model[0].parameters(), model[1].parameters()), lr=param.lr, momentum=param.mom)  

        for epoch in range(param.epochs):
            model[0].train(), model[1].train()
            loss_sum = 0.0
            for step, (x0, x1, y0, y1) in enumerate(train_loader):

                optimizer.zero_grad()

                result0 = model[0](x0)  # detail injection sub-network forward propagation
                result1 = model[1](torch.cat((x1, result0 + x0[:, 0: param.Mbands, :, :]), dim=1)) # unmixing sub-network forward propagation

                loss, AH_data, Y0_data, Y1_data = loss_func(result=result1, y0=y0, y1=y1, param=param) # loss function 

                loss.backward()
                optimizer.step()

                param_update(AH=AH_data, Y0=Y0_data, Y1=Y1_data, param=param) # update Eh, Em, SRF

                train_loss[step: epoch] = loss.item()/Y1_data.shape[1]
                step += 1
                loss_sum += loss.item()
                if step % param.log_step_freq == 0:
                    print("epochs {} / epoch {}, step = {} loss: {}".format(param.epochs, epoch+1, step, loss_sum/step))
                    
            param.print_bar()

    else:       # CCNNF-2
        optimizer = torch.optim.SGD(params=model[0].parameters(), lr=param.lr, momentum=param.mom)

        for epoch in range(param.epochs):        # train the detail-injection sub-network
            model[0].train()
            loss_sum = 0.0
            for step, (x0, _, y0, _, _) in enumerate(train_loader):
                # gradient reset
                optimizer.zero_grad()

                # forward propagation
                outputs = model[0](x0)   # detail injection sub-network forward propagation
                loss = LLoss.rmse4d(y0, outputs) # the MSE loss function for 4-D data

                # backward propagation
                loss.backward()
                optimizer.step()

                step += 1
                # print batch log
                loss_sum += loss.item()
                if step % param.log_step_freq== 0:
                    print("epochs {} / epoch {}, step = {} loss: {}".format(param.epochs, epoch + 1, step, loss_sum / step))
                                  
        optimizer = torch.optim.SGD(params=model[1].parameters(), lr=param.lr, momentum=param.mom)
        for epoch in range(param.epochs):           # train the unmixing sub-network
            model[1].train()
            loss_sum = 0.0
            for step, (_, x1, _, y11, y12) in enumerate(train_loader):
                optimizer.zero_grad()

                results1 = model[1](x1)  # unmixing sub-network forward propagation

                loss, AH_data, Y0_data, Y1_data = loss_func(result=results1, y0=y11, y1=y12, param=param) # loss function 

                loss.backward()
                optimizer.step()

                param_update(AH=AH_data, Y0=Y0_data, Y1=Y1_data, param=param)  # update Eh, Em, SRF

                train_loss[step: epoch] = loss.item()/Y1_data.shape[1]
                step += 1
                loss_sum += loss.item()
                if step % param.log_step_freq == 0:
                    print("epochs {} / epoch {}, step = {} loss: {}".format(param.epochs, epoch + 1, step,
                                                                            loss_sum / step))
            param.print_bar()

    return train_loss
